package SyntaxError;

# this syntax error is intentional!
    {

